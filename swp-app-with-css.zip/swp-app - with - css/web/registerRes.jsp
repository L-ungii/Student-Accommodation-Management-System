<%-- 
    Document   : registerRes
    Created on : 28 Apr 2025, 21:01:13
    Author     : sambo
--%>

<%@page contentType="text/html; pageEncoding=UTF-8" %>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Register Residence Page</title>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
        <script src="https://unpkg.com/@tailwindcss/browser@latest"></script>
        <style>
            body {
                font-family: 'Inter', sans-serif;
                background-color: #f3f4f6;
                background-image: url('385314242_716523280493828_7348133706227184087_n-1500x630.jpg');
                background-size: cover;
                background-repeat: no-repeat;
                backdrop-filter: blur(5px);
            }

            .container {
                max-width: 600px;
                margin: 4rem auto;
                padding: 3rem;
                background-color: rgba(255, 255, 255, 0.4);
                backdrop-filter: blur(12px);
                border-radius: 1.5rem;
                box-shadow: 0 12px 24px -6px rgba(0, 0, 0, 0.15);
                text-align: center;
                border: 1px solid rgba(255, 255, 255, 0.3);
            }

            .heading {
                font-size: 3rem;
                font-weight: 700;
                color: #4f46e5;
                margin-bottom: 2rem;
                text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.05);
            }

            .description {
                font-size: 1.25rem;
                color: #6b7280;
                margin-bottom: 2.5rem;
                text-align: center;
                line-height: 1.75rem;
            }

            .form-container {
                margin-top: 2rem;
                display: flex;
                flex-direction: column;
                align-items: center;
            }

            .form-table {
                width: 100%;
                max-width: 450px;
                margin-bottom: 2rem;
            }

            .form-table tr {
                margin-bottom: 1.5rem;
                display: flex;
                flex-direction: column;
                align-items: flex-start;
            }

            .form-table td {
                padding: 0;
                margin-bottom: 0.75rem;
                width: 100%;
            }

            .form-table td:first-child {
                font-weight: 600;
                color: #4a5568;
                margin-bottom: 0.5rem;
                opacity: 0.9;
            }

            .text-input, .file-input {
                width: 100%;
                padding: 1.25rem;
                border-radius: 0.75rem;
                border: 1px solid rgba(209, 213, 219, 0.6);
                font-size: 1.1rem;
                transition: all 0.3s ease;
                background-color: white;
                box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.08), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            }

            .text-input:focus {
                outline: none;
                border-color: #4f46e5;
                box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.25);
                transform: translateY(-2px);
            }

            .file-input {
                padding-top: 0.75rem;
                padding-bottom: 0.75rem;
            }

            .submit-button {
                padding: 1.25rem 2.5rem;
                background-color: #4f46e5;
                color: #fff;
                font-size: 1.2rem;
                font-weight: 600;
                border-radius: 0.75rem;
                cursor: pointer;
                transition: background-color 0.3s ease, transform 0.2s ease;
                border: none;
                width: 100%;
                max-width: 300px;
                margin: 1.5rem auto;
                box-shadow: 0 6px 8px -2px rgba(0, 0, 0, 0.15), 0 3px 7px -3px rgba(0, 0, 0, 0.1);
            }

            .submit-button:hover {
                background-color: #4338ca;
                transform: translateY(-2px);
                box-shadow: 0 8px 10px -2px rgba(0, 0, 0, 0.2);
            }

            .submit-button:active {
                transform: translateY(0);
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
            }

            .logout-link {
                display: inline-block;
                color: #6b7280;
                font-size: 1rem;
                text-decoration: underline;
                margin-top: 2.5rem;
            }

            .logout-link:hover {
                color: #4f46e5;
                text-decoration: underline;
            }

            @media (max-width: 768px) {
                .container {
                    padding: 2rem;
                    margin: 2rem auto;
                }

                .heading {
                    font-size: 2.5rem;
                }

                .description {
                    font-size: 1.1rem;
                }

                .form-table {
                    max-width: 100%;
                }

                .form-table tr {
                    flex-direction: column;
                    align-items: stretch;
                }

                .form-table td:first-child {
                    text-align: left;
                }

                .submit-button {
                    width: 100%;
                    max-width: 300px;
                }
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1 class="heading">Register Residence</h1>
            <p class="description">
                Enter the details below to register a residence:
            </p>
            <form action="RegisterResidenceServlet.do" method="POST" enctype="multipart/form-data" class="form-container">
                <table class="form-table">
                    <tr>
                        <td>Name of Residence:</td>
                        <td><input type="text" name="resName" required="" class="text-input"></td>
                    </tr>
                    <tr>
                        <td>Location:</td>
                        <td><input type="text" name="location" required="" class="text-input"></td>
                    </tr>
                    <tr>
                        <td>Capacity:</td>
                        <td><input type="text" name="capacity" required="" class="text-input"></td>
                    </tr>
                    <tr>
                        <td>Upload Residence Picture:</td>
                        <td><input type="file" name="resPic" required="" class="file-input"></td>
                    </tr>

                    <tr>
                        <td></td>
                        <td><input type="submit" value="Register Residence" class="submit-button"></td>
                    </tr>
                </table>
            </form>
            <div class="logout-container">
                <a href="index.html" class="logout-link">Logout</a>
            </div>
        </div>
    </body>
</html>
