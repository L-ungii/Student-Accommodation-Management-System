<%@page import="za.ac.tut.enetities.Residence"%>
<%@page import="java.util.List"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <title>Check Space Page</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
        <script src="https://unpkg.com/@tailwindcss/browser@latest"></script>
        <style>
            body {
                font-family: 'Inter', sans-serif;
                background-color: #f3f4f6;
                background-image: url('385314242_716523280493828_7348133706227184087_n-1500x630.jpg');
                background-size: cover;
                background-repeat: no-repeat;
                backdrop-filter: blur(5px);
            }
            .container {
                max-width: 600px;
                margin: 4rem auto;
                padding: 3rem;
                background-color: rgba(255, 255, 255, 0.4);
                border-radius: 1.5rem;
                box-shadow: 0 12px 24px -6px rgba(0, 0, 0, 0.15);
                text-align: center;
            }
            .heading {
                font-size: 3rem;
                font-weight: 700;
                color: #4f46e5;
                margin-bottom: 2rem;
            }
            .description {
                font-size: 1.25rem;
                color: #6b7280;
                margin-bottom: 2.5rem;
            }
            .form-table {
                width: 100%;
                max-width: 450px;
                margin: 0 auto;
            }
            .form-table tr {
                display: flex;
                flex-direction: column;
                align-items: flex-start;
                margin-bottom: 1.5rem;
            }
            .form-table td {
                width: 100%;
                padding-bottom: 0.75rem;
            }
            .form-table td:first-child {
                font-weight: 600;
                color: #4a5568;
            }
            .residence-select {
                width: 100%;
                padding: 1rem;
                border-radius: 0.75rem;
                border: 1px solid #d1d5db;
                font-size: 1rem;
                background-color: white;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.08);
            }
            .residence-select:focus {
                outline: none;
                border-color: #4f46e5;
                box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.25);
            }
            .submit-button {
                padding: 1rem 2rem;
                background-color: #4f46e5;
                color: #fff;
                font-size: 1rem;
                font-weight: 600;
                border-radius: 0.75rem;
                border: none;
                cursor: pointer;
                transition: background-color 0.3s ease;
                width: 100%;
                max-width: 300px;
                margin: 0 auto;
            }
            .submit-button:hover {
                background-color: #4338ca;
            }
            .logout-link {
                display: inline-block;
                margin-top: 2rem;
                color: #6b7280;
                font-size: 0.9rem;
                text-decoration: underline;
            }
            .logout-link:hover {
                color: #4f46e5;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1 class="heading">Check Space</h1>
            <p class="description">Enter a residence to view its capacity:</p>

            <%
                List<Residence> resList = (List<Residence>) request.getAttribute("resList");
            %>

            <form action="CheckSpaceServlet2.do" method="POST">
                <table class="form-table">
                    <tr>
                        <td>Residence Name:</td>
                        <td>
                            <select name="resName" class="residence-select" required>
                                <option value="">Choose an option</option>
                                <%
                                    if (resList != null) {
                                        for (Residence res : resList) {
                                %>
                                <option value="<%=res.getResName()%>"><%=res.getResName()%></option>
                                <%
                                        }
                                    }
                                %>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><input type="submit" value="Check Space" class="submit-button"></td>
                    </tr>
                </table>
            </form>

            <a href="index.html" class="logout-link">Logout</a>
        </div>
    </body>
</html>
