<%@page import="java.util.Base64"%>
<%@page import="java.util.List"%>
<%@page import="za.ac.tut.enetities.Residence"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>View Res Page</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                background-color: #f4f4f4;
                margin: 0;
                padding: 0;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: flex-start;
                min-height: 100vh;
                box-sizing: border-box;
                background-image: url('385314242_716523280493828_7348133706227184087_n-1500x630.jpg');
                background-size: cover;
                background-repeat: no-repeat;
                backdrop-filter: blur(5px);
            }

            h1 {
                color: #333;
                margin-top: 20px;
                text-align: center;
            }

            .container{
                width: 100%;
                max-width: 800px;
                margin-top: 20px;
                padding: 20px;
                border-radius: 12px;
                background-color: rgba(255, 255, 255, 0.4);
                backdrop-filter: blur(10px);
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            }

            h4 {
                
                margin-bottom: 20px;
                text-align: center;
                padding-left: 20px;
                padding-right: 20px;
            }

            .res-box {
                background-color: #fff;
                padding: 20px;
                border-radius: 12px;
                background-color: rgba(255, 255, 255, 0.6);
                backdrop-filter: blur(10px);
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
                margin-bottom: 20px;
                display: flex;
                flex-direction: row;
                align-items: center;
                text-align: left;
            }

            .res-box img {
                border-radius: 8px;
                max-width: 150px;
                height: auto;
                margin-right: 20px;
            }

            .res-info {
                flex: 1;
            }
            .menu-links {
                display: flex;
                justify-content: space-around;
                margin-top: 20px;
                width: 100%;
            }

            ul {
                list-style: none;
                padding: 0;
                margin: 0;
                text-align: center;
            }

            ul li {
                margin-bottom: 10px;
            }

            ul li a {
                color: #007bff;
                text-decoration: none;
            }

            ul li a:hover {
                text-decoration: underline;
            }

            em {
                color: #666;
                font-style: italic;
                display: block;
                text-align: center;
            }
        </style>
    </head>
    <body>
        <h1>View Residence</h1>
        <div class="container">
            <h4>
                Here is the list of residences
            </h4>
            <%
                List<Residence> resList = (List<Residence>) request.getAttribute("resList");
            %>

            <%
                for (int i = 0; i < resList.size(); i++) {
                    byte[] photo = resList.get(i).getResidence_Picture();
                    String base64Image = "";

                    if (photo != null && photo.length > 0) {
                        base64Image = Base64.getEncoder().encodeToString(photo);
            %>
            <div class="res-box">
                <img src="data:image/jpeg;base64,<%= base64Image%>" alt="Residence Photo" width="150" height="150"/>
                <div class="res-info">
                    <%=resList.get(i).getResName()%><br/><%=resList.get(i).getLocation()%>
                </div>
            </div>
            <%
                    } else {
            %>
            <div class="res-box">
                <em>No photo available</em>
                <div class="res-info">
                   <%=resList.get(i).getResName()%><br/><%=resList.get(i).getLocation()%>
                </div>
            </div>
            <%
                    }
                }
            %>
            <div class="menu-links">
                 <a href="studentMenu.html">Menu</a>
                 <a href="index.html">logout</a>
            </div>
        </div>
    </body>
</html>
