<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Cancel Registration</title>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
        <script src="https://unpkg.com/@tailwindcss/browser@latest"></script>
        <style>
            body {
                font-family: 'Inter', sans-serif;
                background-color: #f3f4f6;
                background-image: url('385314242_716523280493828_7348133706227184087_n-1500x630.jpg');
                background-size: cover;
                background-repeat: no-repeat;
                backdrop-filter: blur(5px);
            }
            .container {
                max-width: 600px;
                margin: 2rem auto;
                padding: 2rem;
                background-color: rgba(255, 255, 255, 0.4);
                backdrop-filter: blur(10px);
                border-radius: 1rem;
                box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.05);
                text-align: center;
            }
            .heading {
                font-size: 2.25rem;
                font-weight: 600;
                color: #4f46e5;
                margin-bottom: 1.5rem;
            }
            .message {
                font-size: 1.25rem;
                color: #374151;
                margin-bottom: 2rem;
            }
            .link-list {
                list-style: none;
                padding: 0;
                margin: 0;
                display: flex;
                flex-direction: column;
                align-items: center;
            }
            .link-list li {
                margin-bottom: 0.75rem;
            }
            .link-list li a {
                color: #4f46e5;
                text-decoration: none;
                font-weight: 600;
                font-size: 1rem;
                transition: color 0.2s ease;
            }
            .link-list li a:hover {
                color: #4338ca;
                text-decoration: underline;
            }
            .logout-link {
                color: #6b7280;
                font-size: 0.875rem;
                text-decoration: underline;
                margin-top: 1.5rem;
                display: block;
            }
            .logout-link:hover {
                color: #4f46e5;
            }
        </style>
    </head>
    <body class="bg-gray-100">
        <div class="container">
            <h1 class="heading">Cancel Registration</h1>
            <p class="message">
                You have successfully cancelled your application
            </p>
            <ul class="link-list">
                <li><a href="studentMenu.html">Return to the main menu</a></li>
            </ul>
            <a href="index.html" class="logout-link">logout</a>
        </div>
    </body>
</html>
