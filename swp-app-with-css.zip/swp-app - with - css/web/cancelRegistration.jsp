<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Cancel Registration Page</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">

        <style>
            body {
                font-family: 'Inter', sans-serif;
                background-color: #f3f4f6;
                background-image: url('385314242_716523280493828_7348133706227184087_n-1500x630.jpg');
                background-size: cover;
                background-repeat: no-repeat;
                backdrop-filter: blur(5px);
            }
            .container {
                max-width: 600px;
                margin: 2rem auto;
                padding: 2rem;
                background-color: rgba(255, 255, 255, 0.4);
                backdrop-filter: blur(10px);
                border-radius: 1rem;
                box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.05);
            }
            .heading {
                font-size: 2.25rem;
                font-weight: 600;
                color: #dc2626;
                margin-bottom: 1.5rem;
                text-align: center;
            }
            .description {
                font-size: 1rem;
                color: #6b7280;
                margin-bottom: 1rem;
                text-align: center;
            }
            .form-group {
                margin-bottom: 1.5rem;
            }
            .label {
                display: block;
                font-size: 1rem;
                font-weight: 500;
                color: #374151;
                margin-bottom: 0.5rem;
            }
            .input {
                box-sizing: border-box;
                width: 100%;
                padding: 0.75rem 1rem;
                border-radius: 0.5rem;
                border: 1px solid #d1d5db;
                font-size: 1rem;
                color: #374151;
                transition: border-color 0.15s ease-in-out, shadow-sm 0.15s ease-in-out;
            }
            .input:focus {
                outline: none;
                border-color: #dc2626;
                box-shadow: 0 0 0 3px rgba(220, 38, 38, 0.15);
            }
            .submit-button {
                padding: 0.75rem 1.5rem;
                background-color: #dc2626;
                color: #fff;
                font-size: 1rem;
                font-weight: 600;
                border-radius: 0.5rem;
                border: none;
                cursor: pointer;
                transition: background-color 0.2s ease-in-out, transform 0.1s ease;
                width: 100%;
                display: block;
                margin-left: auto;
                margin-right: auto;
            }
            .submit-button:hover {
                background-color: #c81e1e;
                transform: translateY(-1px);
            }
            .submit-button:active {
                background-color: #b21818;
                transform: translateY(0);
            }
            .logout-link {
                display: block;
                text-align: center;
                margin-top: 2rem;
                color: #6b7280;
                font-size: 0.875rem;
                text-decoration: underline;
            }
            .logout-link:hover {
                color: #dc2626;
            }
        </style>
    </head>
    <body class="bg-gray-100">
        <div class="container">
            <h1 class="heading">Cancel Registration</h1>
            <p class="description">Please enter your student number to cancel your registration</p>

            <form action="CancelRegitrationServlet.do" method="POST">
                <div class="form-group">
                    <label for="studNum" class="label">Student Number:</label>
                    <input type="text" id="studNum" name="studNum" class="input" required>
                </div>
                <div class="form-group">
                    <button type="submit" class="submit-button">Cancel Registration</button>
                </div>
            </form>

            <a href="index.html" class="logout-link">Logout</a>
        </div>
    </body>
</html>
