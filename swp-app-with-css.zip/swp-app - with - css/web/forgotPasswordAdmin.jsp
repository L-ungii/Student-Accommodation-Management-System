<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Forgot Password</title>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
        <script src="https://unpkg.com/@tailwindcss/browser@latest"></script>
        <style>
            body {
                font-family: 'Inter', sans-serif;
                background-color: #f3f4f6;
                background-image: url('385314242_716523280493828_7348133706227184087_n-1500x630.jpg');
                background-size: cover;
                background-repeat: no-repeat;
                backdrop-filter: blur(5px);
            }
            .container {
                max-width: 600px;
                margin: 2rem auto;
                padding: 2rem;
                background-color: rgba(255, 255, 255, 0.4);
                backdrop-filter: blur(10px);
                border-radius: 1rem;
                box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.05);
                text-align: center;
            }
            .heading {
                font-size: 2.25rem;
                font-weight: 600;
                color: #4f46e5;
                margin-bottom: 1.5rem;
            }
            .form-container {
                margin-top: 1.5rem;
                display: flex;
                flex-direction: column;
                align-items: center;
            }
            .form-table {
                width: 100%;
                max-width: 400px;
                margin-bottom: 1rem;
            }
            .form-table tr {
                margin-bottom: 0.75rem;
                display: flex;
                flex-direction: column;
                align-items: flex-start;
            }
            .form-table td {
                padding: 0;
                margin-bottom: 0.5rem;
                width: 100%;
            }
            .form-table td:first-child {
                font-weight: 600;
                color: #374151;
                margin-bottom: 0.25rem;
            }
            .input-field {
                width: 100%;
                padding: 0.75rem;
                border-radius: 0.5rem;
                border: 1px solid #d1d5db;
                font-size: 1rem;
                transition: border-color 0.2s ease;
            }
            .input-field:focus {
                outline: none;
                border-color: #4f46e5;
                box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.2);
            }
            .submit-button {
                padding: 0.75rem 1.5rem;
                background-color: #4f46e5;
                color: #fff;
                font-size: 1rem;
                font-weight: 600;
                border-radius: 0.5rem;
                cursor: pointer;
                transition: background-color 0.2s ease;
                border: none;
                width: 100%;
                max-width: 200px;
                margin-top: 1rem;
            }
            .submit-button:hover {
                background-color: #4338ca;
            }
            .logout-link {
                display: inline-block;
                color: #6b7280;
                font-size: 0.875rem;
                text-decoration: underline;
                margin-top: 1.5rem;
            }
            .logout-link:hover {
                color: #4f46e5;
            }
            @media (max-width: 640px) {
                .form-table tr {
                    flex-direction: column;
                    align-items: stretch;
                }
                .form-table td:first-child {
                    text-align: left;
                }
                .submit-button {
                    width: 100%;
                    max-width: 300px;
                }
            }
        </style>
    </head>
    <body class="bg-gray-100">
        <div class="container">
            <h1 class="heading">Forgot Password</h1>
            <p>
                Enter the details below to update your password
            </p>
            <form action="UpdateServletAdmin.do" method="POST" class="form-container">
                <table class="form-table">
                    <tr>
                        <td>Administrator Number:</td>
                        <td><input type="text" name="adminNum" required="" class="input-field"/></td>
                    </tr>
                    <tr>
                        <td>Password:</td>
                        <td><input type="password" name="password" required="" class="input-field"/></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><input type="submit" value="UPDATE" class="submit-button"/></td>
                    </tr>
                </table>
            </form>
            <a href="index.html" class="logout-link">logout</a>
        </div>
    </body>
</html>
