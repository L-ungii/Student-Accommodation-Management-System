<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>View Residence Page</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                background-color: #f4f4f4;
                margin: 0;
                padding: 0;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                min-height: 100vh;
                box-sizing: border-box;
                background-image: url('385314242_716523280493828_7348133706227184087_n-1500x630.jpg');
                background-size: cover;
                background-repeat: no-repeat;
                backdrop-filter: blur(5px);
            }

            h1 {
                color: #333;
                margin-top: 20px;
                text-align: center;
            }

            p {
                color: #666;
                margin-bottom: 20px;
                text-align: center;
                padding-left: 20px;
                padding-right: 20px;
            }

            form {
            background-color: rgba(255, 255, 255, 0.5);
            backdrop-filter: blur(10px);
            border-radius: 1rem;
            box-shadow: 0 12px 24px rgba(0, 0, 0, 0.2);
            padding: 2.5rem;
            width: 100%;
            max-width: 450px; 
            }

            table {
                margin: 0 auto;
                margin-bottom: 20px;
                width: 100%;
            }

            td {
                padding: 12px;
                text-align: center;
            }

            input[type="submit"] {
                background-color: #007bff;
                color: white;
                border: none;
                padding: 15px 30px;
                border-radius: 8px;
                cursor: pointer;
                transition: background-color 0.3s ease;
                font-size: 1.2em;
            }

            input[type="submit"]:hover {
                background-color: #0056b3;
            }

            ul {
                list-style: none;
                padding: 0;
                margin: 0;
                text-align: center;
            }

            ul li {
                margin-bottom: 10px;
            }

            ul li a {
                color: #007bff;
                text-decoration: none;
            }

            ul li a:hover {
                text-decoration: underline;
            }

            .error-message {
                color: red;
                font-size: 0.9em;
                margin-top: 10px;
                text-align: center;
            }

            .menu-links {
                display: flex;
                justify-content: space-around;
                margin-top: 20px;
                width: 100%;
            }
            .menu-links a{
                color: #007bff;
                text-decoration: none;
            }
             .menu-links a:hover {
                text-decoration: underline;
            }

        </style>
    </head>
    <body>
        <h1>View Residence</h1>


        <form action="ViewResServlet.do" method="GET">
            <p>
                Click the button below to view the residence.
            </p>
            <table>
                <tr>
                    <td></td>
                    <td><input type="submit" value="VIEW RES"></td>
                </tr>
            </table>
            <div class="menu-links">
                 <a href="studentMenu.html">Menu</a>
                 <a href="index.html">logout</a>
            </div>
        </form>

    </body>
</html>
