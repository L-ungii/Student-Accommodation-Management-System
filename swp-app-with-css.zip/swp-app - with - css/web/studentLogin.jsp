<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Login</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/@tailwindcss/browser@latest"></script>
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background-image: url('385314242_716523280493828_7348133706227184087_n-1500x630.jpg'); 
            background-size: cover;
            background-repeat: no-repeat;
            backdrop-filter: blur(5px);
        }
        .login-container {
            background-color: rgba(255, 255, 255, 0.5);
            backdrop-filter: blur(10px);
            border-radius: 1rem;
            box-shadow: 0 12px 24px rgba(0, 0, 0, 0.2);
            padding: 2.5rem;
            width: 100%;
            max-width: 450px;
        }
        .input-field {
            border-radius: 0.75rem;
            padding: 1rem;
            border-width: 1px;
            border-color: rgba(209, 213, 219, 0.7);
            background-color: rgba(255, 255, 255, 0.8);
            color: #374151;
            font-size: 1.2rem;
            box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.06);
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
            height: 3rem;
            width: calc(100% - 2rem); 
        }
        .input-field:focus {
            outline: none;
            border-color: #3b82f6;
            box-shadow: 0 6px 12px rgba(59, 130, 246, 0.25);
        }
        .login-button {
            border-radius: 0.75rem;
            padding: 1rem;
            font-size: 1.2rem;
            font-weight: 600;
            transition: background-color 0.3s ease, transform 0.2s ease, box-shadow 0.6px 10px rgba(59, 130, 246, 0.3);
            height: 3rem;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 100%; 
        }
        .login-button:hover {
            background-color: #2563eb;
            transform: translateY(-2px) scale(1.02);
            box-shadow: 0 8px 15px rgba(59, 130, 246, 0.4);
        }
        .login-button:active {
            transform: translateY(0) scale(1);
            box-shadow: 0 3px 6px rgba(59, 130, 246, 0.3);
        }
        .link-text {
            color: #3b82f6;
            font-weight: 500;
            transition: color 0.2s ease, text-decoration-color 0.2s ease;
            text-decoration: underline;
            text-decoration-color: rgba(59, 130, 246, 0.5);
        }
        .link-text:hover {
            color: #2563eb;
            text-decoration-color: #3b82f6;
        }
    </style>
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen">
    <div class="login-container">
        <h1 class="text-3xl font-semibold text-blue-600 mb-4 text-center">Student Login</h1>
        <p class="text-gray-700 text-center mb-6">Enter your details below to log in</p>
        <form action="LoginServlet.do" method="POST" class="space-y-6">
            <div>
                <label for="studNum" class="block text-gray-700 text-sm font-bold mb-2">Student Number:</label>
                <input type="text" name="studNum" id="studNum" required
                       class="input-field"
                       placeholder="Enter your student number">
            </div>
            <div>
                <label for="password" class="block text-gray-700 text-sm font-bold mb-2">Password:</label>
                <input type="password" name="password" id="password" required
                       class="input-field"
                       placeholder="Enter your password">
            </div>
            <button type="submit" class="login-button bg-blue-500 hover:bg-blue-600 text-white w-full">
                LOGIN
            </button>
        </form>
        <div class="mt-6 text-center">
            <a href="StudentSignUp.jsp" class="link-text">Sign Up</a>
        </div>
        <div class="mt-3 text-center">
            <a href="forgotPassword.jsp" class="link-text text-sm">Forgot Password?</a>
        </div>
        <div class="mt-8 text-center">
            <a href="index.html" class="link-text text-sm text-red-500 hover:text-red-700">Logout</a>
        </div>
    </div>
    
</body>
</html>
