<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Reserve Outcome Page</title>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
        <script src="https://unpkg.com/@tailwindcss/browser@latest"></script>
        <style>
            body {
                font-family: 'Inter', sans-serif;
                background-color: #f3f4f6;
                background-image: url('385314242_716523280493828_7348133706227184087_n-1500x630.jpg');
                background-size: cover;
                background-repeat: no-repeat;
                backdrop-filter: blur(5px);
            }
            .container {
                max-width: 600px;
                margin: 2rem auto;
                padding: 2rem;
                background-color: rgba(255, 255, 255, 0.4);
                backdrop-filter: blur(10px);
                border-radius: 1rem;
                box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.05);
                text-align: center;
            }
            .heading {
                font-size: 2.25rem;
                font-weight: 600;
                color: #4f46e5;
                margin-bottom: 1.5rem;
            }
            .success-message {
                font-size: 1rem;
                color: #22c55e;
                margin-bottom: 1.5rem;
                padding: 1rem;
                background-color: #ecfdf5;
                border-radius: 0.75rem;
                border: 1px solid #d1fae5;
            }
            .link-list {
                list-style: none;
                padding: 0;
                margin-bottom: 1rem;
            }
            .link-list li {
                margin-bottom: 0.75rem;
            }
            .link-list li a {
                color: #3b82f6;
                text-decoration: none;
                font-size: 1rem;
            }
            .link-list li a:hover {
                color: #2563eb;
                text-decoration: underline;
            }
            .logout-link {
                display: inline-block;
                color: #6b7280;
                font-size: 0.875rem;
                text-decoration: underline;
            }
            .logout-link:hover {
                color: #4f46e5;
            }
        </style>
    </head>
    <body class="bg-gray-100">
        <div class="container">
            <h1 class="heading">Thank you</h1>
            <p class="success-message">
                You have successfully reserved a room.
            </p>
            <ul class="link-list">
                <li><a href="studentMenu.html">Return to Main Menu</a></li>
                <li><a href="index.html" class="logout-link">Logout</a></li>
            </ul>
        </div>
    </body>
</html>
