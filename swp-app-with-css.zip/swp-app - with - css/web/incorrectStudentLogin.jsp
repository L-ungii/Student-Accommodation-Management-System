<%@page isErrorPage="true" contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Incorrect Student Login</title>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
        <script src="https://unpkg.com/@tailwindcss/browser@latest"></script>
        <style>
            body {
                font-family: 'Inter', sans-serif;
                background-color: #f3f4f6;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                min-height: 100vh;
                margin: 0;
                background-image: url('385314242_716523280493828_7348133706227184087_n-1500x630.jpg');
                background-size: cover;
                background-repeat: no-repeat;
                backdrop-filter: blur(5px);
            }
            .container {
                background-color: rgba(255, 255, 255, 0.4);
                backdrop-filter: blur(10px);
                padding: 2rem;
                border-radius: 1rem;
                box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.05);
                text-align: center;
                max-width: 600px;
                width: 95%;
            }
            .heading {
                font-size: 2.25rem;
                font-weight: 600;
                color: #dc2626;
                margin-bottom: 1rem;
            }
            .message {
                font-size: 1rem;
                color: #4b5563;
                margin-bottom: 1.5rem;
            }
            .back-link {
                color: #4f46e5;
                text-decoration: underline;
                font-size: 1rem;
                margin-bottom: 1rem;
            }
            .back-link:hover {
                color: #4338ca;
            }
            .logout-link {
                display: inline-block;
                color: #6b7280;
                font-size: 0.875rem;
                text-decoration: underline;
                margin-top: 1rem;
            }
            .logout-link:hover {
                color: #4f46e5;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1 class="heading">Incorrect Login Info</h1>
            <p class="message">
                Please enter the correct student number and password.
            </p>
            <p>
                Click <a href="studentLogin.jsp" class="back-link">here</a> to go back.
            </p>
            <p>
                <a href="index.html" class="logout-link">logout</a>
            </p>
        </div>
    </body>
</html>
