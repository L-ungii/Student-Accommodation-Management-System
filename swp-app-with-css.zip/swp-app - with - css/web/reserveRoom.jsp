<%@ page import="za.ac.tut.enetities.Residence" %>
<%@ page import="java.util.List" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Reserve a Room</title>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">

        <style>
            body {
                font-family: 'Inter', sans-serif;
                background-color: #f3f4f6;
                background-image: url('385314242_716523280493828_7348133706227184087_n-1500x630.jpg');
                background-size: cover;
                background-repeat: no-repeat;
                backdrop-filter: blur(5px);
            }
            .container {
                max-width: 600px;
                margin: 2rem auto;
                padding: 2rem;
                background-color: rgba(255, 255, 255, 0.4);
                backdrop-filter: blur(10px);
                border-radius: 1rem;
                box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.05);
            }
            .heading {
                font-size: 2.25rem;
                font-weight: 600;
                color: #4f46e5;
                margin-bottom: 1.5rem;
                text-align: center;
            }
            .description {
                font-size: 1rem;
                color: #6b7280;
                margin-bottom: 1rem;
                text-align: center;
            }
            .form-group {
                margin-bottom: 1.5rem;
            }
            .label {
                display: block;
                font-size: 1rem;
                font-weight: 500;
                color: #374151;
                margin-bottom: 0.5rem;
            }
            .input, .select {
                box-sizing: border-box;
                width: 100%;
                padding: 0.75rem 1rem;
                border-radius: 0.5rem;
                border: 1px solid #d1d5db;
                font-size: 1rem;
                color: #374151;
                transition: border-color 0.15s ease-in-out, shadow-sm 0.15s ease-in-out;
            }
            .input:focus, .select:focus {
                outline: none;
                border-color: #4f46e5;
                box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.15);
            }
            .select {
                appearance: none;
                background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 20 20' fill='currentColor'%3E%3Cpath fill-rule='evenodd' d='M5.23 7.21a.75.75 0 011.06.02L10 11.168l3.71-3.938a.75.75 0 011.08 1.04l-4.25 4.5a.75.75 0 01-1.08 0l-4.25-4.5a.75.75 0 01.02-1.06z' clip-rule='evenodd'/%3E%3C/svg%3E");
                background-repeat: no-repeat;
                background-position: right 0.75rem center;
                background-size: 1rem 1rem;
                padding-right: 2.5rem;
            }
            .select:focus {
                background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 20 20' fill='currentColor'%3E%3Cpath fill-rule='evenodd' d='M5.23 7.21a.75.75 0 011.06.02L10 11.168l3.71-3.938a.75.75 0 011.08 1.04l-4.25 4.5a.75.75 0 01-1.08 0l-4.25-4.5a.75.75 0 01.02-1.06z' clip-rule='evenodd'/%3E%3C/svg%3E");
            }
            .submit-button {
                padding: 0.75rem 1.5rem;
                background-color: #4f46e5;
                color: #fff;
                font-size: 1rem;
                font-weight: 600;
                border-radius: 0.5rem;
                border: none;
                cursor: pointer;
                transition: background-color 0.2s ease-in-out, transform 0.1s ease;
                width: 100%;
                display: block;
                margin-left: auto;
                margin-right: auto;
            }
            .submit-button:hover {
                background-color: #4338ca;
                transform: translateY(-1px);
            }
            .submit-button:active {
                background-color: #3730a3;
                transform: translateY(0);
            }
            .logout-link {
                display: block;
                text-align: center;
                margin-top: 1.5rem;
                color: #6b7280;
                font-size: 0.875rem;
                text-decoration: underline;
            }
            .logout-link:hover {
                color: #4f46e5;
            }
            .error-message {
                color: #dc2626;
                font-size: 0.875rem;
                margin-top: 0.5rem;
            }
        </style>
    </head>
    <body class="bg-gray-100">
        <div class="container">
            <h1 class="heading">Reserve a Room</h1>
            <p class="description">Enter the details below to reserve a room:</p>

            <%
                List<Residence> resList = (List<Residence>) request.getAttribute("resList");
                if (resList == null || resList.isEmpty()) {
            %>
            <p class="error-message">No residences available at the moment.</p>
            <%
                }
            %>

            <form action="ReseveRoomServlet2.do" method="POST">
                <div class="form-group">
                    <label for="studNum" class="label">Student Number:</label>
                    <input type="text" id="studNum" name="studNum" class="input" required>
                </div>

                <div class="form-group">
                    <label for="roomType" class="label">Room Type:</label>
                    <select id="roomType" name="roomType" class="select" required>
                        <option value="Single">Single</option>
                        <option value="Double">Double</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="resName" class="label">Residence Name:</label>
                    <select id="resName" name="resName" class="select" required>
                        <option value="">Choose an option</option>
                        <%
                            if (resList != null && !resList.isEmpty()) {
                                for (Residence residence : resList) {
                        %>
                        <option value="<%=residence.getResName()%>"><%=residence.getResName()%></option>
                        <%
                                }
                            }
                        %>
                    </select>
                </div>

                <div class="form-group">
                    <label for="reservation_year" class="label">Reservation Year:</label>
                    <input type="text" id="reservation_year" name="reservation_year" class="input" required>
                </div>

                <button type="submit" class="submit-button">Reserve Room</button>
            </form>

            <a href="index.html" class="logout-link">Logout</a>
        </div>
    </body>
</html>
